# -*- coding: utf-8 -*-
from odoo import models, fields
from odoo.http import request


class AppointmentType(models.Model):
    _inherit = 'appointment.type'

    # Extend selection field with Employee
    schedule_based_on = fields.Selection(
        selection_add=[('employee', 'Employees')],
        ondelete={'employee': 'set default'},
    )

    # New field to link with employee
    employee_ids = fields.Many2many(
        'hr.employee',
        'appointment_type_employee_rel',
        'appointment_type_id',
        'employee_id',
        string="Employees",
        help="Select employees available for this appointment"
    )

    def _prepare_appointment_type_page_values(
        self, appointment_type, staff_user_id=False, resource_selected_id=False, employee_id=False, **kwargs
    ):
        # Call parent logic
        values = super()._prepare_appointment_type_page_values(
            appointment_type,
            staff_user_id=staff_user_id,
            resource_selected_id=resource_selected_id,
            **kwargs
        )

        # Extend logic for employee
        if appointment_type.schedule_based_on == 'employee':
            employees_possible = self.env['hr.employee'].sudo().search([])  # adjust domain if needed
            employee_selected = employee_default = False  # FIX: start as False

            if employee_id and employee_id in employees_possible.ids:
                employee_selected = self.env['hr.employee'].sudo().browse(employee_id)
            elif employees_possible:
                employee_default = employees_possible[0]

            values.update({
                'employees_possible': employees_possible,
                'employee_default': employee_default,
                'employee_selected': employee_selected,
                'hide_select_dropdown': len(employees_possible) <= 1,
            })

        return values

    
