# -*- coding: utf-8 -*-
{
    'name': 'Appointment Schedule Employee',
    "version": "18.0.1.0.0",
    'summary': 'Add Employee option in appointment schedule',
    'description': 'This module adds an Employee option to the schedule_based_on field in appointment types and shows it in the form view.',
    'category': 'Appointments',
    'author': "Muhammad Ahsan Absar",
    'website': "https://www.linkedin.com/in/ahsanazhar13/",
    'images': ['static/description/icon.png'],
    'license': 'LGPL-3',
    'depends': ['appointment', 'hr'],
    'data': [
        'views/appointment_type_views.xml',
    ],
    'installable': True,
    'application': False,
}
