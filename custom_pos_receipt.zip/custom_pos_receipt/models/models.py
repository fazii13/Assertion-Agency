# -*- coding: utf-8 -*-

from odoo import models, fields, api


class PosOrder(models.Model):
    _inherit = 'pos.order'
    
    def get_custom_receipt_data(self):
        """Get formatted data for custom receipt"""
        self.ensure_one()
        return {
            'order': self,
            'lines': self.lines,
            'company': self.company_id,
            'cashier': self.user_id.name if self.user_id else False,
            'payments': self.statement_ids,
        }

