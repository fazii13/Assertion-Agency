# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json
import logging

_logger = logging.getLogger(__name__)


class CustomPosReceipt(http.Controller):
    @http.route('/custom_pos_receipt/generate_pdf', type='http', auth='user', methods=['POST'], csrf=False)
    def generate_pdf_report(self, **kwargs):
        """Generate PDF report for POS order"""
        try:
            _logger.info("Custom PDF generation request received")
            
            # Get data from request
            if request.httprequest.data:
                data = json.loads(request.httprequest.data.decode('utf-8'))
            else:
                data = request.params
            
            order_id = data.get('order_id')
            _logger.info(f"Order ID received: {order_id}")
            
            if not order_id:
                return request.make_json_response({'error': 'Order ID is required'}, status=400)
            
            # Get the POS order
            order = request.env['pos.order'].browse(int(order_id))
            if not order.exists():
                return request.make_json_response({'error': 'Order not found'}, status=404)
            
            _logger.info(f"Order found: {order.name}")
            
            # Generate PDF report using direct template rendering
            try:
                report = request.env.ref("custom_pos_receipt.action_pos_order_report")
                pdf_content, _ = report._render_qweb_pdf(
                    "custom_pos_receipt.action_pos_order_report",  # report_ref
                    res_ids=[order.id]                            # records
                )
                        # pass res_ids explicitly


                
                _logger.info(f"PDF content generated, size: {len(pdf_content)} bytes")
                
            except Exception as e:
                _logger.error(f"Error in PDF generation: {str(e)}", exc_info=True)
                return request.make_json_response({'error': f'PDF generation failed: {str(e)}'}, status=500)
            
            # Return PDF as base64 encoded string
            import base64
            pdf_base64 = base64.b64encode(pdf_content).decode('utf-8')
            
            _logger.info("PDF generated successfully")
            
            return request.make_json_response({
                'success': True,
                'pdf_content': pdf_base64,
                'filename': f'pos_receipt_{order.name}.pdf'
            })
            
        except Exception as e:
            _logger.error(f"Error generating PDF: {str(e)}", exc_info=True)
            return request.make_json_response({'error': str(e)}, status=500)

