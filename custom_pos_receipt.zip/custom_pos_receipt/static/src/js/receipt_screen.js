/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";

patch(ReceiptScreen.prototype, {
    setup() {
        super.setup();
        // Initialize the custom print method
        this.doCustomPrint = this.doCustomPrint.bind(this);
        this.doCustomPrint.status = 'idle';
    },

    async doCustomPrint() {
        console.log("Custom print button clicked");
        
        try {
            this.doCustomPrint.status = 'loading';
            
            // Get the current order
            const order = this.pos.get_order();
            if (!order || !order.id) {
                throw new Error("No order found to print");
            }
            
            console.log("Generating PDF for order:", order.id);
            
            // Call the controller to generate PDF using fetch
            const response = await fetch('/custom_pos_receipt/generate_pdf', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify({
                    order_id: order.id
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                // Create and download the PDF
                this.downloadPDF(data.pdf_content, data.filename);
                console.log("PDF generated successfully");
            } else {
                throw new Error(data.error || "Failed to generate PDF");
            }
            
        } catch (error) {
            console.error("Error in custom print:", error);
            // You might want to show a notification to the user
            this.showNotification("Error generating PDF: " + error.message, "error");
        } finally {
            this.doCustomPrint.status = 'idle';
        }
    },

    downloadPDF(pdfContent, filename) {
        try {
            // Convert base64 to blob
            const byteCharacters = atob(pdfContent);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: 'application/pdf' });
            
            // Create download link
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Error downloading PDF:", error);
            throw error;
        }
    },

    showNotification(message, type = 'info') {
        // Simple notification - you might want to use Odoo's notification system
        console.log(`${type.toUpperCase()}: ${message}`);
        // You can implement a proper notification here if needed
    }
});
