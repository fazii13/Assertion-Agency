# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import pprint

from odoo import _, fields, models
from odoo.exceptions import ValidationError

from odoo.addons.payment import utils as payment_utils
from odoo.addons.payment_flooss import utils as flooss_utils  # You'll need to create this
from odoo.addons.payment_flooss.const import PAYMENT_STATUS_MAPPING  # You'll need to define mapping

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    # For debugging or tracking purposes
    flooss_type = fields.Char(string="Flooss Transaction Type")

    def _get_specific_processing_values(self, processing_values):
        """Override to return Flooss-specific processing values."""
        res = super()._get_specific_processing_values(processing_values)
        if self.provider_code != 'flooss':
            return res

        payload = self._flooss_prepare_order_payload()

        _logger.info(
            "Sending '/checkout/orders' request for transaction with reference %s:\n%s",
            self.reference, pprint.pformat(payload)
        )
        idempotency_key = payment_utils.generate_idempotency_key(
            self, scope='payment_request_order'
        )
        order_data = self.provider_id._flooss_make_request(
            '/v1/orders', json_payload=payload, idempotency_key=idempotency_key
        )
        _logger.info(
            "Response of '/checkout/orders' request for transaction with reference %s:\n%s",
            self.reference, pprint.pformat(order_data)
        )
        return {'order_id': order_data['id']}

    def _flooss_prepare_order_payload(self):
        """Prepare the payload for Flooss create order request."""
        country_code = self.partner_country_id.code or self.company_id.country_id.code
        partner_first_name, partner_last_name = payment_utils.split_partner_name(self.partner_name)
        payload = {
            'intent': 'CAPTURE',
            'purchase_units': [
                {
                    'reference_id': self.reference,
                    'description': f'{self.company_id.name}: {self.reference}',
                    'amount': {
                        'currency_code': self.currency_id.name,
                        'value': self.amount,
                    },
                    'merchant': {
                        'email_address': flooss_utils.get_normalized_email_account(self.provider_id),
                        'display_name': self.provider_id.company_id.name,
                    },
                },
            ],
            'payer': {
                'name': {
                    'given_name': partner_first_name,
                    'surname': partner_last_name,
                },
                'address': {
                    'address_line_1': self.partner_address,
                    'admin_area_1': self.partner_state_id.name,
                    'admin_area_2': self.partner_city,
                    'postal_code': self.partner_zip,
                    'country_code': country_code,
                },
            },
        }
        if self.partner_email:
            payload['payer']['email_address'] = self.partner_email

        return payload

    def _get_tx_from_notification_data(self, provider_code, notification_data):
        """Override to find the transaction based on Flooss notification."""
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'flooss' or len(tx) == 1:
            return tx

        reference = notification_data.get('reference_id')
        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'flooss')])
        if not tx:
            raise ValidationError(
                "Flooss: " + _("No transaction found matching reference %s.", reference)
            )
        return tx

    def _process_notification_data(self, notification_data):
        """Override to process Flooss notification data."""
        super()._process_notification_data(notification_data)
        if self.provider_code != 'flooss':
            return

        if not notification_data:
            self._set_canceled(state_message=_("The customer left the payment page."))
            return

        amount = notification_data.get('amount', {}).get('value')
        currency_code = notification_data.get('amount', {}).get('currency_code')
        assert amount and currency_code, "Flooss: missing amount or currency"
        assert self.currency_id.compare_amounts(float(amount), self.amount) == 0, \
            "Flooss: mismatching amounts"
        assert currency_code == self.currency_id.name, "Flooss: mismatching currency codes"

        txn_id = notification_data.get('id')
        txn_type = notification_data.get('txn_type')
        if not all((txn_id, txn_type)):
            raise ValidationError(
                "Flooss: " + _(
                    "Missing value for txn_id (%(txn_id)s) or txn_type (%(txn_type)s).",
                    txn_id=txn_id, txn_type=txn_type
                )
            )
        self.provider_reference = txn_id
        self.flooss_type = txn_type

        self.payment_method_id = self.env['payment.method'].search(
            [('code', '=', 'flooss')], limit=1
        ) or self.payment_method_id

        payment_status = notification_data.get('status')

        if payment_status in PAYMENT_STATUS_MAPPING['pending']:
            self._set_pending(state_message=notification_data.get('pending_reason'))
        elif payment_status in PAYMENT_STATUS_MAPPING['done']:
            self._set_done()
        elif payment_status in PAYMENT_STATUS_MAPPING['cancel']:
            self._set_canceled()
        else:
            _logger.info(
                "Received data with invalid payment status (%s) for transaction with reference %s",
                payment_status, self.reference
            )
            self._set_error(
                "Flooss: " + _("Received data with invalid payment status: %s", payment_status)
            )
