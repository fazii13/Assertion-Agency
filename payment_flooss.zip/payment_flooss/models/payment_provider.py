# Part of Odoo. See LICENSE file for full copyright and licensing details.

import json
import logging
import pprint
import requests

from datetime import timedelta
from werkzeug import urls

from odoo import _, fields, models
from odoo.exceptions import UserError, ValidationError

from odoo.addons.payment_flooss import const
from odoo.addons.payment_flooss.controllers import FloossController

_logger = logging.getLogger(__name__)


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('flooss', "Flooss")], ondelete={'flooss': 'set default'}
    )
    flooss_merchant_email = fields.Char(
        string="Flooss Merchant Email",
        help="The public business email used to identify the account with Flooss",
        required_if_provider='flooss',
        default=lambda self: self.env.company.email,
    )
    flooss_client_id = fields.Char(string="Flooss Client ID", required_if_provider='flooss')
    flooss_client_secret = fields.Char(string="Flooss Client Secret", groups='base.group_system')
    flooss_access_token = fields.Char(
        string="Flooss Access Token",
        help="The short-lived token used to access Flooss APIs",
        groups='base.group_system',
    )
    flooss_access_token_expiry = fields.Datetime(
        string="Flooss Access Token Expiry",
        help="The moment at which the access token becomes invalid.",
        default='1970-01-01',
        groups='base.group_system',
    )
    flooss_webhook_id = fields.Char(string="Flooss Webhook ID")

    # === ACTION METHODS === #

    def action_flooss_create_webhook(self):
        """ Create a new webhook.

        Note: This action only works for instances using a public URL.
        """
        base_url = self.get_base_url()
        if 'localhost' in base_url:
            raise UserError(
                "Flooss: " + _("You must have an HTTPS connection to generate a webhook.")
            )
        data = {
            'url': urls.url_join(base_url, FloossController._webhook_url),
            'event_types': [{'name': event_type} for event_type in const.HANDLED_WEBHOOK_EVENTS]
        }
        webhook_data = self._flooss_make_request('/v1/webhooks', json_payload=data)
        self.flooss_webhook_id = webhook_data.get('id')

    # === BUSINESS METHODS === #

    def _flooss_make_request(
        self, endpoint, data=None, json_payload=None, auth=None, is_refresh_token_request=False,
        idempotency_key=None,
    ):
        """ Make a request to Flooss API at the specified endpoint. """
        self.ensure_one()
        url = self._flooss_get_api_url() + endpoint
        headers = {'Content-Type': 'application/json'}
        if idempotency_key:
            headers['Flooss-Request-Id'] = idempotency_key
        if not is_refresh_token_request:
            headers['Authorization'] = f'Bearer {self._flooss_fetch_access_token()}'
        try:
            response = requests.post(
                url, headers=headers, data=data, json=json_payload, auth=auth, timeout=10
            )
            try:
                response.raise_for_status()
            except requests.exceptions.HTTPError:
                payload = data or json_payload
                _logger.exception(
                    "Invalid API request at %s with data:\n%s", url, pprint.pformat(payload)
                )
                msg = response.json().get('message', '')
                raise ValidationError(
                    "Flooss: " + _("The communication with the API failed. Details: %s", msg)
                )
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            _logger.exception("Unable to reach endpoint at %s", url)
            raise ValidationError("Flooss: " + _("Could not establish the connection to the API."))
        return response.json()

    def _flooss_fetch_access_token(self):
        """ Generate a new access token if expired, else return the existing one. """
        if fields.Datetime.now() > self.flooss_access_token_expiry - timedelta(minutes=5):
            response_content = self._flooss_make_request(
                '/v1/oauth/token',
                data={'grant_type': 'client_credentials'},
                auth=(self.flooss_client_id, self.flooss_client_secret),
                is_refresh_token_request=True,
            )
            access_token = response_content.get('access_token')
            if not access_token:
                raise ValidationError("Flooss: " + _("Could not generate a new access token."))
            self.write({
                'flooss_access_token': access_token,
                'flooss_access_token_expiry': fields.Datetime.now() + timedelta(
                    seconds=response_content['expires_in']
                ),
            })
        return self.flooss_access_token

    # === BUSINESS METHODS - GETTERS === #

    def _get_supported_currencies(self):
        supported_currencies = super()._get_supported_currencies()
        if self.code == 'flooss':
            supported_currencies = supported_currencies.filtered(
                lambda c: c.name in const.SUPPORTED_CURRENCIES
            )
        return supported_currencies

    def _flooss_get_api_url(self):
        """ Return API URL depending on environment. """
        self.ensure_one()
        if self.state == 'enabled':
            return 'https://api.flooss.com'
        else:
            return 'https://sandbox.flooss.com'

    def _get_default_payment_method_codes(self):
        default_codes = super()._get_default_payment_method_codes()
        if self.code != 'flooss':
            return default_codes
        return const.DEFAULT_PAYMENT_METHOD_CODES

    def _flooss_get_inline_form_values(self, currency=None):
        """ Values needed to render inline payment form. """
        inline_form_values = {
            'provider_id': self.id,
            'client_id': self.flooss_client_id,
            'currency_code': currency and currency.name,
        }
        return json.dumps(inline_form_values)
