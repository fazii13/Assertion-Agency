# Part of Odoo. See LICENSE file for full copyright and licensing details.

# ISO 4217 codes of currencies supported by Flooss
# Replace this with actual supported currencies for Flooss if available.
SUPPORTED_CURRENCIES = (
    'AED',  # Assuming Flooss operates mainly in UAE Dirham
    'SAR',  # Saudi Riyal
    'USD',  # US Dollar
)

# The codes of the payment methods to activate when Flooss is activated.
DEFAULT_PAYMENT_METHOD_CODES = {
    'flooss',
}

# Mapping of transaction states to Flooss payment statuses.
# Update these according to Flooss API docs.
PAYMENT_STATUS_MAPPING = {
    'pending': (
        'PENDING',
        'CREATED',
        'AWAITING_APPROVAL',  # Example custom state
    ),
    'done': (
        'COMPLETED',
        'SUCCESS',
    ),
    'cancel': (
        'DECLINED',
        'CANCELLED',
        'VOIDED',
    ),
    'error': ('FAILED', 'ERROR'),
}

# Events which are handled by the webhook.
# Update with actual Flooss webhook event names if available.
HANDLED_WEBHOOK_EVENTS = [
    'PAYMENT.COMPLETED',
    'PAYMENT.APPROVED',
    'PAYMENT.REVERSED',
]
