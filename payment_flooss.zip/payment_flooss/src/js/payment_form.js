/** @odoo-module **/

import { loadJS } from '@web/core/assets';
import { _t } from '@web/core/l10n/translation';
import { rpc, RPCError } from '@web/core/network/rpc';

import paymentForm from '@payment/js/payment_form';

paymentForm.include({
    inlineFormValues: undefined,
    floossColor: 'blue',
    selectedOptionId: undefined,
    floossData: undefined,

    // #=== DOM MANIPULATION ===#

    /**
     * Hide Flooss button container if the expanded inline form is another provider.
     *
     * @private
     */
    async _expandInlineForm(radio) {
        const providerCode = this._getProviderCode(radio);
        if (providerCode !== 'flooss') {
            document.getElementById('o_flooss_button')?.classList.add('d-none');
            document.getElementById('o_flooss_button_container')?.classList.add('d-none');
        }
        this._super(...arguments);
    },

    /**
     * Prepare the inline form of Flooss for direct payment.
     *
     * @override
     */
    async _prepareInlineForm(providerId, providerCode, paymentOptionId, paymentMethodCode, flow) {
        if (providerCode !== 'flooss') {
            this._super(...arguments);
            return;
        }

        this._hideInputs();
        this._setPaymentFlow('direct');
        document.getElementById('o_flooss_loading').classList.remove('d-none');

        this.floossData ??= {};

        if (this.selectedOptionId && this.selectedOptionId !== paymentOptionId) {
            this.floossData[this.selectedOptionId]['enabledButton'].hide();
            this.floossData[this.selectedOptionId]['disabledButton']?.hide();
        }

        const currentFloossData = this.floossData[paymentOptionId];

        if (currentFloossData && this.selectedOptionId !== paymentOptionId) {
            const floossSDKURL = this.floossData[paymentOptionId]['sdkURL'];
            const enabledButton = this.floossData[paymentOptionId]['enabledButton'];
            const disabledButton = this.floossData[paymentOptionId]['disabledButton'];
            await loadJS(floossSDKURL);
            enabledButton?.show();
            disabledButton?.show();
        }
        else if (!currentFloossData) {
            this.floossData[paymentOptionId] = {};
            const radio = document.querySelector('input[name="o_payment_radio"]:checked');
            if (radio) {
                this.inlineFormValues = JSON.parse(radio.dataset['floossInlineFormValues']);
                this.floossColor = radio.dataset['floossColor'];
            }

            // Load your Flooss SDK (replace with your actual SDK URL or logic)
            const { client_id, currency_code } = this.inlineFormValues;
            const floossSDKURL = `https://flooss.com/sdk/js?client-id=${client_id}&currency=${currency_code}`;
            this.floossData[paymentOptionId]['sdkURL'] = floossSDKURL;
            await loadJS(floossSDKURL);

            // Create the enabled Flooss button
            const enabledButton = Flooss.Buttons({
                style: {
                    color: this.floossColor,
                    label: 'pay',
                    disableMaxWidth: true,
                    borderRadius: 6,
                },
                createOrder: this._floossOnClick.bind(this),
                onApprove: this._floossOnApprove.bind(this),
                onCancel: this._floossOnCancel.bind(this),
                onError: this._floossOnError.bind(this),
            });
            const enabledButtonContainer = document.getElementById('o_flooss_enabled_button');
            if (enabledButtonContainer) {
                enabledButton.render('#o_flooss_enabled_button');
            } else {
                enabledButton.render('#o_flooss_button');
            }
            this.floossData[paymentOptionId]['enabledButton'] = enabledButton;

            // Create the disabled Flooss button
            const disabledButtonContainer = document.getElementById('o_flooss_disabled_button');
            if (disabledButtonContainer) {
                const disabledButton = Flooss.Buttons({
                    style: {
                        color: 'silver',
                        label: 'pay',
                        disableMaxWidth: true,
                        borderRadius: 6,
                    },
                    onInit: (data, actions) => actions.disable(),
                });
                disabledButton.render('#o_flooss_disabled_button');
                this.floossData[paymentOptionId]['disabledButton'] = disabledButton;
            }
        }

        document.getElementById('o_flooss_loading').classList.add('d-none');
        document.getElementById('o_flooss_button')?.classList.remove('d-none');
        document.getElementById('o_flooss_button_container')?.classList.remove('d-none');
        this.selectedOptionId = paymentOptionId;
    },

    // #=== PAYMENT FLOW ===#

    async _floossOnClick() {
        await this._submitForm(new Event("FloossClickEvent"));
        return this.floossData[this.selectedOptionId].floossOrderId;
    },

    _processDirectFlow(providerCode, paymentOptionId, paymentMethodCode, processingValues) {
        if (providerCode !== 'flooss') {
            this._super(...arguments);
            return;
        }
        this.floossData[paymentOptionId].floossOrderId = processingValues['order_id'];
        this.floossData[paymentOptionId].floossTxRef = processingValues['reference'];
    },

    async _floossOnApprove(data) {
        const orderID = data.orderID;
        const { provider_id } = this.inlineFormValues;

        await rpc('/payment/flooss/complete_order', {
            provider_id: provider_id,
            order_id: orderID,
            reference: this.floossData[this.selectedOptionId].floossTxRef,
        }).then(() => {
            this.floossData[this.selectedOptionId]['enabledButton'].close();
            window.location = '/payment/status';
        }).catch(error => {
            if (error instanceof RPCError) {
                this._displayErrorDialog(_t("Payment processing failed"), error.data.message);
                this._enableButton();
            }
            return Promise.reject(error);
        });
    },

    _floossOnCancel() {
        this._enableButton();
    },

    _floossOnError(error) {
        const message = error.message;
        this._enableButton();
        if (message !== "Detected popup close" && !(error instanceof RPCError)) {
            this._displayErrorDialog(_t("Payment processing failed"), message);
        }
    },
});
