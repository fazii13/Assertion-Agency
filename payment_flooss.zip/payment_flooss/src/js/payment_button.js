/** @odoo-module **/

import paymentButton from '@payment/js/payment_button';

paymentButton.include({

    /**
     * Show the enabled Flooss button and hide the disabled one.
     *
     * @override
     * @private
     */
    _setEnabled() {
        if (!this.paymentButton.dataset.isFlooss) {
            this._super(...arguments);
            return;
        }
        document.getElementById('o_flooss_disabled_button').classList.add('d-none');
        document.getElementById('o_flooss_enabled_button').classList.remove('d-none');
    },

    /**
     * Show the disabled Flooss button and hide the enabled one.
     *
     * @override
     * @private
     */
    _disable() {
        if (!this.paymentButton.dataset.isFlooss) {
            this._super(...arguments);
            return;
        }
        document.getElementById('o_flooss_disabled_button').classList.remove('d-none');
        document.getElementById('o_flooss_enabled_button').classList.add('d-none');
    },

    /**
     * Disable the generic behavior that hides the Flooss button container.
     *
     * @override
     * @private
     */
    _hide() {
        if (!this.paymentButton.dataset.isFlooss) {
            this._super(...arguments);
        }
    },

    /**
     * Disable the generic behavior that shows the Flooss button container.
     *
     * @override
     * @private
     */
    _show() {
        if (!this.paymentButton.dataset.isFlooss) {
            this._super(...arguments);
        }
    },

});
