# Part of Odoo. See LICENSE file for full copyright and licensing details.

import json
import logging
import pprint

from werkzeug.exceptions import Forbidden

from odoo import _, http
from odoo.exceptions import ValidationError
from odoo.http import request

_logger = logging.getLogger(__name__)


class FloossController(http.Controller):
    # AJAX endpoints and webhook endpoints
    _request_otp_url = '/payment/flooss/request_otp'
    _verify_otp_url = '/payment/flooss/verify_otp'
    _complete_url = '/payment/flooss/complete_order'   # optional: poll/check final status
    _webhook_url = '/payment/flooss/webhook/'

    @http.route(_request_otp_url, type='json', auth='public', methods=['POST'])
    def flooss_request_otp(self, provider_id, phone):
        """
        Step 1: Merchant -> server -> FLOOSS verify-customer endpoint that sends OTP.
        :param int provider_id: id of payment.provider handling FLOOSS
        :param str phone: 8-digit phone number (without country code)
        :return: dict (whatever provider method returns) or raise ValidationError
        """
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        # provider should implement _flooss_request_otp(phone) which:
        # - ensures token present
        # - calls Flooss verify-customer endpoint and triggers OTP
        # - returns the normalized response or raises meaningful exceptions
        response = provider_sudo._flooss_request_otp(phone)
        # Optionally create a 'pending' transaction record here if you want to bind OTP => tx
        return response

    @http.route(_verify_otp_url, type='json', auth='public', methods=['POST'])
    def flooss_verify_otp(self, provider_id, phone, otp, tx_reference=None):
        """
        Step 2: Merchant -> server -> FLOOSS verify-customer-otp endpoint.
        On success, should send the payment request to FLOOSS (or return success so frontend calls payment).
        :param int provider_id: id of payment.provider handling FLOOSS
        :param str phone: 8-digit phone number
        :param str otp: raw otp entered by user (server side will encrypt as per FLOOSS spec)
        :param str tx_reference: optional payment.transaction reference (to link with tx)
        :return: dict with verification and/or payment request response
        """
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        # provider implements _flooss_verify_otp(phone, otp)
        verify_response = provider_sudo._flooss_verify_otp(phone, otp)
        # if verification successful, either:
        # - provider triggers a payment request immediately (preferred), returning payment response
        # - or backend returns a success to frontend which will call another endpoint to send payment request
        # Here we try to trigger the payment request if provider offers it:
        payment_request_resp = None
        if verify_response.get('status') in ('OTP_VERIFIED', 'VERIFIED', 'success'):
            # If tx_reference provided, get tx and use it in request flow
            tx_sudo = None
            if tx_reference:
                tx_sudo = request.env['payment.transaction'].sudo().search([('reference', '=', tx_reference)], limit=1)
            # provider should implement _flooss_send_payment_request(tx_sudo, phone) OR accept tx data
            # If tx_sudo is None, provider implementation may create the transaction internally.
            try:
                payment_request_resp = provider_sudo._flooss_send_payment_request(tx_sudo, phone)
            except Exception as e:
                _logger.exception("Error sending Flooss payment request: %s", e)
                # return verify_response and error details so frontend can show message
                return {'verify': verify_response, 'payment_request': None, 'error': str(e)}
        return {'verify': verify_response, 'payment_request': payment_request_resp}

    @http.route(_complete_url, type='json', auth='public', methods=['POST'])
    def flooss_complete_order(self, provider_id, reference_id):
        """
        Optional: Merchant polls this endpoint (or calls once) to check final payment status
        by asking FLOOSS 'Online Checkout Request Status' API.
        :param int provider_id: provider record id
        :param str|int reference_id: referenceId returned by FLOOSS in payment-request response
        """
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        # provider should implement _flooss_check_status(reference_id) which calls FLOOSS status API
        response = provider_sudo._flooss_check_status(reference_id)
        normalized = self._normalize_flooss_data(response)
        # find the transaction and let Odoo transaction handle notification mapping
        try:
            tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data('flooss', normalized)
            tx_sudo._handle_notification_data('flooss', normalized)
        except ValidationError:
            _logger.warning("Flooss: unable to find transaction for reference %s, skipping handle.", reference_id)
        return response

    @http.route(_webhook_url, type='http', auth='public', methods=['POST'], csrf=False)
    def flooss_webhook(self):
        """
        Webhook receiver for FLOOSS Online Checkout Notification API.

        FLOOSS will POST something like:
        {
            "status": "SUCCESS",
            "transactionNumber": 123
        }
        The provider should configure a 'notify_jwt' or 'notify_secret' stored on provider config to verify origin.
        """
        data = request.get_json_data()
        _logger.info("Notification received from FLOOSS with data:\n%s", pprint.pformat(data))

        # We need to find the tx referenced in notification.
        normalized_data = self._normalize_flooss_data(data, from_webhook=True)

        try:
            tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
                'flooss', normalized_data
            )
            # Verify origin: ensure the Authorization header matches the provider's stored notify token
            self._verify_notification_origin(data, tx_sudo)
            # Let transaction handle transitions
            tx_sudo._handle_notification_data('flooss', normalized_data)
        except ValidationError:
            # Acknowledge even if we cannot process, to avoid repeated webhook calls
            _logger.warning("Unable to handle FLOOSS webhook notification; acknowledging to avoid retries.")
        except Forbidden:
            # If origin verification fails, we should log and return 403
            _logger.warning("FLOOSS webhook origin verification failed.")
            return request.make_response("Forbidden", 403)

        return request.make_json_response('')

    def _normalize_flooss_data(self, data, from_webhook=False):
        """
        Normalize FLOOSS data for Odoo transaction lookup and handling.

        FLOOSS webhook payload example:
        { "status": "SUCCESS", "transactionNumber": 123 }

        FLOOSS payment-request response example:
        { "message": "...", "code": 1, "data": { "id": ..., "merchantId": ..., "qrCode": "...", "createdAt": "...", "referenceId": 123 } }

        This must return a dict containing at least 'reference_id' and 'status' keys.
        """
        result = {}
        # If it's a webhook, straightforward mapping
        if from_webhook:
            result = {
                'reference_id': data.get('transactionNumber') or data.get('transactionNumber'),
                'status': data.get('status'),
                'id': data.get('transactionNumber'),
            }
        else:
            # For API responses (payment-request or status check), try to extract referenceId and status
            # If response includes 'data' with 'referenceId':
            if isinstance(data, dict) and data.get('data') and isinstance(data.get('data'), dict):
                d = data.get('data')
                result = {
                    'reference_id': d.get('referenceId') or d.get('id'),
                    'status': data.get('status') or data.get('message') or 'UNKNOWN',
                    'id': d.get('referenceId') or d.get('id'),
                    **d,
                }
            else:
                # fallback
                result = {
                    'reference_id': data.get('referenceId') or data.get('id'),
                    'status': data.get('status') or data.get('message') or 'UNKNOWN',
                    'id': data.get('referenceId') or data.get('id'),
                }
        return result

    def _verify_notification_origin(self, notification_data, tx_sudo):
        """
        Verify that webhook is coming from FLOOSS.

        Approach:
        - Check Authorization header 'Bearer <token>' equals the provider stored notify secret (e.g. notify_jwt)
        - The provider model should expose e.g. tx_sudo.provider_id.flooss_notify_jwt or similar config field.

        :param dict notification_data: the raw payload
        :param recordset tx_sudo: sudoed payment.transaction referenced in the notification data
        :raises Forbidden: if verification fails
        """
        headers = request.httprequest.headers
        auth_header = headers.get('Authorization') or headers.get('authorization') or ''
        bearer = None
        if auth_header.startswith('Bearer '):
            bearer = auth_header.split(' ', 1)[1].strip()
        # provider stores notify token on provider config: flooss_notify_jwt (change name if different)
        provider = tx_sudo.provider_id if tx_sudo else None
        expected = None
        if provider:
            expected = provider.flooss_notify_jwt if hasattr(provider, 'flooss_notify_jwt') else None

        # If there's no expected token configured, still allow if the admin intentionally left it blank?
        if expected:
            if bearer != expected:
                _logger.warning("FLOOSS webhook Authorization mismatch. Received: %s, Expected: %s", bearer, expected)
                raise Forbidden()
        else:
            # If provider has no notify token configured, we can still allow but log a warning
            _logger.warning("FLOOSS webhook notify token not configured on provider %s. Unable to strictly verify origin.", provider.id if provider else 'unknown')