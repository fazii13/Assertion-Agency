# Part of Odoo. See LICENSE file for full copyright and licensing details.

import json
import logging
import pprint
import base64
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

from werkzeug.exceptions import Forbidden

from odoo import _, http
from odoo.exceptions import ValidationError
from odoo.http import request

_logger = logging.getLogger(__name__)


class FloossController(http.Controller):
    _request_otp_url = '/payment/flooss/request_otp'
    _verify_otp_url = '/payment/flooss/verify_otp'
    _complete_url = '/payment/flooss/complete_order'
    _webhook_url = '/payment/flooss/webhook/'

    @http.route(_request_otp_url, type='json', auth='public', methods=['POST'])
    def flooss_request_otp(self, provider_id, phone):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        response = provider_sudo._flooss_request_otp(phone)
        return response

    @http.route(_verify_otp_url, type='json', auth='public', methods=['POST'])
    def flooss_verify_otp(self, provider_id, phone, otp, tx_reference=None):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        encrypted_otp = provider_sudo._flooss_encrypt_otp(otp)
        verify_response = provider_sudo._flooss_verify_otp(phone, encrypted_otp)
        payment_request_resp = None
        if verify_response.get('status') in ('OTP_VERIFIED', 'VERIFIED', 'success'):
            tx_sudo = None
            if tx_reference:
                tx_sudo = request.env['payment.transaction'].sudo().search([('reference', '=', tx_reference)], limit=1)
            try:
                payment_request_resp = provider_sudo._flooss_send_payment_request(tx_sudo, phone)
            except Exception as e:
                _logger.exception("Error sending Flooss payment request: %s", e)
                return {'verify': verify_response, 'payment_request': None, 'error': str(e)}
        return {'verify': verify_response, 'payment_request': payment_request_resp}

    @http.route(_complete_url, type='json', auth='public', methods=['POST'])
    def flooss_complete_order(self, provider_id, reference_id, phone=None, amount=None):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        response = provider_sudo._flooss_check_status(reference_id, phone=phone, amount=amount)
        normalized = self._normalize_flooss_data(response)
        try:
            tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data('flooss', normalized)
            tx_sudo._handle_notification_data('flooss', normalized)
        except ValidationError:
            _logger.warning("Flooss: unable to find transaction for reference %s, skipping handle.", reference_id)
        return response

    def action_flooss_create_webhook(self):
        raise ValidationError(_("Flooss does not support webhook creation via API. Please configure the webhook URL manually in your Flooss merchant portal."))

    def _normalize_flooss_data(self, data, from_webhook=False):
        result = {}
        if from_webhook:
            result = {
                'reference_id': data.get('transactionNumber'),
                'status': data.get('status'),
                'id': data.get('transactionNumber'),
            }
        else:
            if isinstance(data, dict) and data.get('data') and isinstance(data.get('data'), dict):
                d = data.get('data')
                result = {
                    'reference_id': d.get('referenceId') or d.get('id'),
                    'status': data.get('status') or data.get('message') or 'UNKNOWN',
                    'id': d.get('referenceId') or d.get('id'),
                    **d,
                }
            else:
                result = {
                    'reference_id': data.get('referenceId') or data.get('id'),
                    'status': data.get('status') or data.get('message') or 'UNKNOWN',
                    'id': data.get('referenceId') or data.get('id'),
                }
        return result

    def _verify_notification_origin(self, notification_data, tx_sudo):
        headers = request.httprequest.headers
        auth_header = headers.get('Authorization') or headers.get('authorization') or ''
        bearer = None
        if auth_header.startswith('Bearer '):
            bearer = auth_header.split(' ', 1)[1].strip()
        provider = tx_sudo.provider_id if tx_sudo else None
        expected = provider.flooss_notify_jwt if provider and hasattr(provider, 'flooss_notify_jwt') else None
        if expected:
            if bearer != expected:
                _logger.warning("FLOOSS webhook Authorization mismatch. Received: %s, Expected: %s", bearer, expected)
                raise Forbidden()
        else:
            _logger.warning("FLOOSS webhook notify token not configured on provider %s.", provider.id if provider else 'unknown')
