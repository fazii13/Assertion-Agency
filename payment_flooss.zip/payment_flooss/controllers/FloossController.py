# Part of Odoo. See LICENSE file for full copyright and licensing details.

import json
import logging

import urllib.parse

import werkzeug

from odoo import _, http, fields
from odoo.exceptions import AccessError, ValidationError
from odoo.http import request

from odoo.addons.payment import utils as payment_utils
from odoo.addons.payment.controllers.post_processing import PaymentPostProcessing
from odoo.addons.portal.controllers import portal

from werkzeug.exceptions import Forbidden

from odoo import _, http
from odoo.exceptions import ValidationError
from odoo.http import request

_logger = logging.getLogger(__name__)


class FloossController(http.Controller):
    _request_otp_url = '/payment/flooss/request_otp'
    _verify_otp_url = '/payment/flooss/verify_otp'
    _complete_url = '/payment/flooss/complete_order'
    _webhook_url = '/payment/flooss/webhook/'
    


    
    @http.route(_request_otp_url, type='json', auth='public', methods=['POST'])
    def flooss_request_otp(self, provider_id, phone):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        _logger.info("Flooss: OTP request received. Provider ID: %s, Phone: %s", provider_id, phone)
        response = provider_sudo._flooss_request_otp(phone)
        _logger.info("Flooss: OTP request response: %s", response)
        return response

    @http.route('/payment/flooss/create_transaction', type='json', auth='public', methods=['POST'])
    def create_flooss_transaction(self, provider_id, amount):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()

        # Create a new transaction
        tx_sudo = request.env['payment.transaction'].sudo().create({
            'acquirer_id': provider_sudo.id,
            'amount': amount,
            'currency_id': provider_sudo.currency_id.id,
            'reference': request.env['payment.transaction']._generate_reference(),
            'state': 'draft',
            'provider_code': 'flooss',
            'partner_id': request.env.user.partner_id.id,
        })

        return {'tx_reference': tx_sudo.reference, 'amount': tx_sudo.amount}

    @http.route('/payment/flooss/verify_otp', type='json', auth='public', methods=['POST'])
    def flooss_verify_otp(self, provider_id, phone, otp, tx_reference=None):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        _logger.info("Flooss: OTP verification started. Provider ID: %s, Phone: %s, Tx Reference: %s", provider_id, phone, tx_reference)
        
        # Encrypt OTP
        try:
            encrypted_otp = provider_sudo._flooss_encrypt_otp(otp)
            _logger.info("Flooss Encrypted OTP: %s", encrypted_otp)

        except ValidationError as e:
            return {'verify': None, 'payment_request': None, 'error': str(e)}

        _logger.debug("Flooss: Encrypted OTP: %s", encrypted_otp)

        # Call verify OTP API
        try:
            verify_response = provider_sudo._flooss_verify_otp(phone, encrypted_otp)
            
            # If API returned string instead of dict, wrap in dict
            if isinstance(verify_response, str):
                verify_response = {'message': verify_response}

        except ValidationError as e:
            # This happens when API returns HTTP 417, 400 etc.
            verify_response = None
            return {'verify': None, 'payment_request': None, 'error': str(e)}
        except Exception as e:
            verify_response = None
            _logger.exception("Unexpected error verifying OTP: %s", e)
            return {'verify': None, 'payment_request': None, 'error': str(e)}

        _logger.info("Flooss: OTP verification response: %s", verify_response)
        return {
        'verify': verify_response,
        'error': None
    }
    @http.route('/payment/flooss/success', type='http', auth='public', website=True)
    def flooss_payment_success(self, **kwargs):
        """
        Success page for Flooss payments with order details
        """
        try:
            # Get parameters from URL
            order_id = kwargs.get('order_id', '')
            tx_reference = kwargs.get('tx_ref', '')
            payment_status = kwargs.get('payment_status', 'success')

            # Try to get additional data from session or database
            success_data = {}

            # If we have a transaction reference, try to get transaction details
            if tx_reference:
                tx = request.env['payment.transaction'].sudo().search([
                    ('reference', '=', tx_reference)
                ], limit=1)

                if tx:
                    success_data.update({
                        'transaction': tx,
                        'order': tx.sale_order_ids and tx.sale_order_ids[0] or None,
                        'amount': tx.amount,
                        'currency': tx.currency_id.symbol if tx.currency_id else '',
                        'partner': tx.partner_id,
                        'state': tx.state,
                        'reference': tx.reference,
                        'provider': tx.provider_id.name if tx.provider_id else 'Flooss',
                    })

                    # If transaction has a sale order, get order details
                    if tx.sale_order_ids:
                        order = tx.sale_order_ids[0]
                        success_data.update({
                            'order_name': order.name,
                            'order_date': order.date_order,
                            'order_amount': order.amount_total,
                            'order_lines': order.order_line,
                        })

            # Fallback data structure
            if not success_data:
                success_data = {
                    'order_id': order_id,
                    'tx_reference': tx_reference,
                    'payment_status': payment_status,
                    'provider': 'Flooss',
                }

            # Additional context for the template
            values = {
                'success_data': success_data,
                'page_title': 'Payment Successful',
                'show_order_details': bool(success_data.get('order')),
                'order_id': order_id,
                'tx_reference': tx_reference,
            }

            return request.render('payment_flooss.flooss_payment_success_template', values)

        except Exception as e:
            _logger.error("Error rendering Flooss success page: %s", str(e))

            # Fallback simple success page
            values = {
                'error_message': 'Unable to load payment details, but your payment was successful.',
                'order_id': kwargs.get('order_id', ''),
                'tx_reference': kwargs.get('tx_ref', ''),
            }
            return request.render('payment_flooss.flooss_payment_success_simple', values)

    @http.route(_complete_url, type='json', auth='public', methods=['POST'])
    def flooss_complete_order(self, provider_id, reference_id, phone=None, amount=None):
        provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
        response = provider_sudo._flooss_check_status(reference_id, phone=phone, amount=amount)
        normalized = self._normalize_flooss_data(response)
        try:
            tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data('flooss', normalized)
            tx_sudo._handle_notification_data('flooss', normalized)
        except ValidationError:
            _logger.warning("Flooss: unable to find transaction for reference %s, skipping handle.", reference_id)
        return response

    def action_flooss_create_webhook(self):
        raise ValidationError(_("Flooss does not support webhook creation via API. Please configure the webhook URL manually in your Flooss merchant portal."))

    def _normalize_flooss_data(self, data, from_webhook=False):
        result = {}
        if from_webhook:
            result = {
                'reference_id': data.get('transactionNumber'),
                'status': data.get('status'),
                'id': data.get('transactionNumber'),
            }
        else:
            if isinstance(data, dict) and data.get('data') and isinstance(data.get('data'), dict):
                d = data.get('data')
                result = {
                    'reference_id': d.get('referenceId') or d.get('id'),
                    'status': data.get('status') or data.get('message') or 'UNKNOWN',
                    'id': d.get('referenceId') or d.get('id'),
                    **d,
                }
            else:
                result = {
                    'reference_id': data.get('referenceId') or data.get('id'),
                    'status': data.get('status') or data.get('message') or 'UNKNOWN',
                    'id': data.get('referenceId') or data.get('id'),
                }
        return result

    def _verify_notification_origin(self, notification_data, tx_sudo):
        headers = request.httprequest.headers
        auth_header = headers.get('Authorization') or headers.get('authorization') or ''
        bearer = None
        if auth_header.startswith('Bearer '):
            bearer = auth_header.split(' ', 1)[1].strip()
        provider = tx_sudo.provider_id if tx_sudo else None
        expected = provider.flooss_notify_jwt if provider and hasattr(provider, 'flooss_notify_jwt') else None
        if expected:
            if bearer != expected:
                _logger.warning("FLOOSS webhook Authorization mismatch. Received: %s, Expected: %s", bearer, expected)
                raise Forbidden()
        else:
            _logger.warning("FLOOSS webhook notify token not configured on provider %s.", provider.id if provider else 'unknown')

    # Corrected Controller Code

    @http.route('/payment/flooss/proceed_payment', type='json', auth='public', website=True, methods=['POST'])
    def flooss_proceed_payment(self, provider_id, phone, tx_reference):
        """Process Flooss payment and return success data for frontend redirect"""
        try:
            provider_sudo = request.env['payment.provider'].browse(provider_id).sudo()
            sale_order_id = request.website.sale_get_order()

            if not sale_order_id:
                return {'error': 'No active order found'}

            # Handle transaction creation/retrieval - SIMPLIFIED LOGIC
            payment_transaction = request.env['payment.transaction'].sudo().search([
                ('reference', '=', tx_reference)
            ], limit=1)

            if not payment_transaction:
                payment_transaction = request.env['payment.transaction'].sudo().create({
                    'provider_id': provider_sudo.id,
                    'payment_method_id': provider_sudo.payment_method_ids[
                        0].id if provider_sudo.payment_method_ids else False,
                    'reference': tx_reference,
                    'amount': sale_order_id.amount_total,
                    'currency_id': sale_order_id.currency_id.id,
                    'partner_id': sale_order_id.partner_id.id,
                    'sale_order_ids': [(4, sale_order_id.id)],
                })

            try:
                # Call Flooss API
                payment_request_resp = provider_sudo._flooss_send_payment_request(payment_transaction, phone)
                response_code = payment_request_resp.get('code')

                if response_code == 0:
                    error_message = payment_request_resp.get('message')
                    if error_message == "Success":
                        ref_id = payment_request_resp.get('data', {}).get('referenceId')
                        created_at_flooss = payment_request_resp.get('data', {}).get('createdAt')
                        status = payment_request_resp.get('message')

                        # Update transaction with Flooss data
                        payment_transaction.write({
                            'flooss_type': 'ONLINE_CHECKOUT',
                            'flooss_reference_id': ref_id,
                            'flooss_created_at': created_at_flooss,
                            'flooss_payment_status': status,
                            'state': 'done',
                            'provider_reference': f'FLOOSS_{sale_order_id.name}_{tx_reference}',
                        })

                        # Confirm the sale order if needed
                        if sale_order_id.state in ['draft', 'sent']:
                            sale_order_id.sudo().action_confirm()

                        # Create payment request data
                        payment_request = {
                            'order_id': f'FLOOSS_{sale_order_id.id}_{sale_order_id.name}',
                            'reference': payment_transaction.reference,
                            'amount': float(sale_order_id.amount_total),
                            'currency': sale_order_id.currency_id.name,
                            'order_number': sale_order_id.name,
                            'transaction_id': payment_transaction.id,
                        }
                        redirect_url = f'/payment/thank-you?amount={sale_order_id.amount_total}&currency={sale_order_id.currency_id.symbol}&order_number={sale_order_id.name}&tx_ref={tx_reference}&payment_method=flooss&status=success'

                        return {
                            'success': True,
                            'payment_request': payment_request,
                            'redirect_url': redirect_url,
                            'message': 'Payment processed successfully',
                            'provider': 'Flooss Payment Gateway'
                        }
                    else:
                        return {'error': f'Payment failed: {error_message}'}
                else:
                    error_message = payment_request_resp.get('message', 'Unknown error occurred')
                    return {'error': f'Payment request failed: {error_message}'}

            except Exception as e:
                _logger.exception("Error sending Flooss payment request: %s", e)
                return {'error': f'Payment request failed: {str(e)}'}

        except Exception as e:
            _logger.exception("Error in flooss_proceed_payment: %s", e)
            return {'error': f'Payment processing failed: {str(e)}'}

    @http.route('/payment/thank-you', type='http', auth='public', website=True)
    def payment_thank_you(self, **kwargs):
        """Thank you page after successful payment"""
        try:
            # Extract parameters from URL
            amount = kwargs.get('amount', '')
            currency = kwargs.get('currency', '$')
            order_number = kwargs.get('order_number', '')
            tx_reference = kwargs.get('tx_ref', '')
            payment_method = kwargs.get('payment_method', 'Flooss').title()
            status = kwargs.get('status', 'success')

            # Get additional order details if transaction reference exists
            order_details = {}
            transaction = None

            if tx_reference:
                transaction = request.env['payment.transaction'].sudo().search([
                    ('reference', '=', tx_reference)
                ], limit=1)

                if transaction and transaction.sale_order_ids:
                    order = transaction.sale_order_ids[0]
                    order_details = {
                        'order': order,
                        'order_lines': order.order_line,
                        'partner': order.partner_id,
                        'order_date': order.date_order,
                        'total_amount': order.amount_total,
                    }

            # Prepare template values
            values = {
                'amount': amount,
                'currency': currency,
                'order_number': order_number,
                'tx_reference': tx_reference,
                'payment_method': payment_method,
                'status': status,
                'transaction': transaction,
                'order_details': order_details,
                'page_title': 'Thank You - Payment Successful',
                'current_datetime': fields.Datetime.now(),
            }

            _logger.info("Thank you page rendered for order: %s", order_number)

            # Render the thank you template
            return request.render('payment_flooss.payment_thank_you_template', values)

        except Exception as e:
            _logger.error("Error rendering thank you page: %s", str(e))

            # Fallback to simple success message
            fallback_values = {
                'amount': kwargs.get('amount', ''),
                'currency': kwargs.get('currency', '$'),
                'order_number': kwargs.get('order_number', ''),
                'error_occurred': True,
                'error_message': 'Payment was successful, but some details could not be loaded.'
            }
            return request.render('payment_flooss.payment_thank_you_simple', fallback_values)

