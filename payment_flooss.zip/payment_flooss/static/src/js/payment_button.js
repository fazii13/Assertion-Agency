/** @odoo-module **/

import paymentButton from '@payment/js/payment_button';

paymentButton.include({

    /**
     * Check if the current payment option is Flooss
     * @private
     * @returns {boolean}
     */
    _isFloossSelected() {
        const selectedRadio = document.querySelector('input[name="o_payment_radio"]:checked');
        return selectedRadio && selectedRadio.dataset.isFlooss === 'True';
    },

    /**
     * Show the enabled Flooss button and hide the disabled one.
     * @override
     * @private
     */
    _setEnabled() {
        if (!this._isFloossSelected()) {
            this._super(...arguments);
            return;
        }

        // Show Flooss button container
        const container = document.getElementById('o_flooss_button_container');
        const enabledBtn = document.getElementById('o_flooss_enabled_button');
        const disabledBtn = document.getElementById('o_flooss_disabled_button');

        if (container) container.classList.remove('d-none');
        if (enabledBtn) enabledBtn.classList.remove('d-none');
        if (disabledBtn) disabledBtn.classList.add('d-none');
    },

    /**
     * Show the disabled Flooss button and hide the enabled one.
     * @override
     * @private
     */
    _disable() {
        if (!this._isFloossSelected()) {
            this._super(...arguments);
            return;
        }

        // Show Flooss button container with disabled state
        const container = document.getElementById('o_flooss_button_container');
        const enabledBtn = document.getElementById('o_flooss_enabled_button');
        const disabledBtn = document.getElementById('o_flooss_disabled_button');

        if (container) container.classList.remove('d-none');
        if (enabledBtn) enabledBtn.classList.add('d-none');
        if (disabledBtn) disabledBtn.classList.remove('d-none');
    },

    /**
     * Hide Flooss buttons when not selected
     * @override
     * @private
     */
    _hide() {
        if (!this._isFloossSelected()) {
            this._super(...arguments);
            return;
        }

        // Hide Flooss button container
        const container = document.getElementById('o_flooss_button_container');
        const enabledBtn = document.getElementById('o_flooss_enabled_button');
        const disabledBtn = document.getElementById('o_flooss_disabled_button');

        if (container) container.classList.add('d-none');
        if (enabledBtn) enabledBtn.classList.add('d-none');
        if (disabledBtn) disabledBtn.classList.add('d-none');
    },

    /**
     * Show Flooss buttons when selected
     * @override
     * @private
     */
    _show() {
        if (!this._isFloossSelected()) {
            this._super(...arguments);
            return;
        }

        // Show Flooss button container
        const container = document.getElementById('o_flooss_button_container');
        if (container) {
            container.classList.remove('d-none');
        }
        // Determine which button to show based on current state
        this._isFormValid() ? this._setEnabled() : this._disable();
    },

    /**
     * Override to handle radio button changes
     * @override
     */
    start() {
        const result = this._super(...arguments);

        // Listen for radio button changes
        document.addEventListener('change', (event) => {
            if (event.target.name === 'o_payment_radio') {
                // Hide all Flooss buttons first
                const container = document.getElementById('o_flooss_button_container');
                const enabledBtn = document.getElementById('o_flooss_enabled_button');
                const disabledBtn = document.getElementById('o_flooss_disabled_button');

                if (container) container.classList.add('d-none');
                if (enabledBtn) enabledBtn.classList.add('d-none');
                if (disabledBtn) disabledBtn.classList.add('d-none');

                // If Flooss is selected, show appropriate button
                if (this._isFloossSelected()) {
                    this._show();
                }
            }
        });

        return result;
    },

    /**
     * Check if form is valid (override or add your validation logic)
     * @private
     * @returns {boolean}
     */
    _isFormValid() {
        // Add your form validation logic here
        // For now, return true if Flooss is selected
        return this._isFloossSelected();
    }

});