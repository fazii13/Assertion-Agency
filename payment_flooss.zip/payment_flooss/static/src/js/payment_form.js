/** @odoo-module **/

import { rpc } from '@web/core/network/rpc';
import paymentForm from '@payment/js/payment_form';

paymentForm.include({

    floossData: {},

    async _prepareInlineForm(providerId, providerCode, paymentOptionId) {
        if (providerCode !== 'flooss') {
            await this._super(...arguments);
            return;
        }

        this._hideInputs();
        this._setPaymentFlow('direct');

        const radio = document.querySelector('input[name="o_payment_radio"]:checked');
        if (radio) {
            this.inlineFormValues = JSON.parse(radio.dataset['floossInlineFormValues']);
        }

        this.selectedOptionId = paymentOptionId;

        // Get the transaction reference from the form or create one
        this.selectedTxReference = this._getTxReference();

        document.getElementById('o_flooss_button_container')?.classList.remove('d-none');
        document.getElementById('o_flooss_enabled_button')?.classList.remove('d-none');

        document.getElementById('o_flooss_enabled_button').onclick = async () => await this._floossOnClick();
    },

    async _getSelectedPhone() {
        // Ask backend for the selected order contacts
        const resp = await rpc('/payment/flooss/current_order_contact', {});

        if (resp?.error === 'no_order') {
            throw new Error("No active order found.");
        }

        // Prefer delivery phone; fall back to billing
        const phone = resp.shipping_phone || resp.billing_phone || '';
        if (!phone) {
            throw new Error("No phone number on the selected delivery/billing address.");
        }

        console.log("📦 partner_shipping_id:", resp.partner_shipping_id,
                    "🧾 partner_invoice_id:", resp.partner_invoice_id,
                    "📞 using phone:", phone);
        return phone;
    },

    _getTxReference() {
        // Try to get transaction reference from form data
        const txRefInput = document.querySelector('input[name="reference"]');
        if (txRefInput) {
            return txRefInput.value;
        }

        // Try to get from inline form values
        if (this.inlineFormValues && this.inlineFormValues.tx_reference) {
            return this.inlineFormValues.tx_reference;
        }

        // Try to get from the payment form's transaction reference
        if (this.txContext && this.txContext.reference) {
            return this.txContext.reference;
        }

        // Generate a temporary reference if none found (for testing)
        return 'FLOOSS-' + Date.now();
    },

    async _floossOnClick() {
        const { provider_id } = this.inlineFormValues;
        const phone = await this._getSelectedPhone();
        console.log(" phone is ", phone);

        // COMMENTED OUT: Create transaction controller call
        // const txResp = await rpc('/payment/flooss/create_transaction', {
        //     provider_id: provider_id,
        //     amount: this.getOrderTotal(), // Implement getOrderTotal() to return checkout total
        // });
        // this.selectedTxReference = txResp.tx_reference;

        const modalEl = document.getElementById('floossOtpModal');
        if (!modalEl) return;
        const modal = new bootstrap.Modal(modalEl);
        modal.show();

        const infoBox = document.getElementById('floossOtpInfo');
        const otpInputDiv = document.querySelector('#floossOtpInput')?.closest('.mb-3');
        const submitBtn = document.getElementById('floossOtpSubmit');
        const tryAgainBtn = document.getElementById('floossOtpTryAgain');
        const errorBox = document.getElementById('floossOtpError');
        const proceedBtn = document.getElementById('floossProceedPayment');
        const cancelBtn = document.getElementById('floossCancelPayment');

        // Reset modal state
        infoBox.classList.add('d-none');
        otpInputDiv.classList.add('d-none');
        submitBtn.classList.add('d-none');
        tryAgainBtn.classList.add('d-none');
        errorBox.classList.add('d-none');
        proceedBtn?.classList.add('d-none');
        cancelBtn?.classList.add('d-none');

        document.getElementById('o_flooss_loading')?.classList.remove('d-none');

        const USER_EXIST = "User exists on FLOOSS. OTP has been sent to the entered mobile.";

        try {
            // Request OTP
            const otpResp = await rpc('/payment/flooss/request_otp', { provider_id, phone });

            infoBox.textContent = otpResp;
            infoBox.classList.remove('d-none');
            if (otpResp.includes(USER_EXIST)) {
                otpInputDiv.classList.remove('d-none');
                submitBtn.classList.remove('d-none');
            } else {
                otpInputDiv.classList.add('d-none');
                submitBtn.classList.add('d-none');
            }

        } catch (err) {
            this._showFloossError(err.message);
            return;
        } finally {
            document.getElementById('o_flooss_loading')?.classList.add('d-none');
        }

        // Handle Verify Pay click
        submitBtn.onclick = async () => {
            const otpValue = document.getElementById('floossOtpInput').value.trim();
            if (!otpValue) {
                this._showFloossError("Please enter the OTP");
                return;
            }
            try {
                const verifyResp = await rpc('/payment/flooss/verify_otp', {
                    provider_id,
                    phone,
                    otp: otpValue,
                    tx_reference: this.selectedTxReference,
                });

                if (verifyResp.error) throw new Error(verifyResp.error);

                const message = verifyResp.verify?.message || "";
                if (message.includes("The OTP user entered has been verified.")) {
                    // hide verify button
                    submitBtn.classList.add('d-none');
                    // show Proceed + Cancel
                    proceedBtn.classList.remove('d-none');
                    cancelBtn.classList.remove('d-none');

                    // Proceed handler - THIS IS THE KEY CHANGE
                    proceedBtn.onclick = async () => {
                        try {
                            // Show loading state
                            proceedBtn.disabled = true;
                            proceedBtn.innerHTML = '<i class="fa fa-spinner fa-spin me-2"></i>Processing...';

                            const payResp = await rpc('/payment/flooss/proceed_payment', {
                                provider_id,
                                phone,
                                tx_reference: this.selectedTxReference,
                            });

                            if (payResp.error) throw new Error(payResp.error);

                            this.floossData[this.selectedOptionId] = {
                                floossOrderId: payResp.payment_request?.order_id,
                                floossTxRef: payResp.payment_request?.reference,
                            };

                            this._showFloossSuccess("Payment processed successfully! Redirecting...");

                            // REDIRECT TO THE THANK YOU PAGE
                            setTimeout(() => {
                                if (payResp.redirect_url) {
                                    window.location.href = payResp.redirect_url;
                                } else {
                                    // Fallback redirect
                                    window.location.href = '/payment/thank-you';
                                }
                            }, 1000);

                        } catch (err) {
                            console.error('Payment processing error:', err);
                            this._showFloossError(err.message);
                            // Reset button state
                            proceedBtn.disabled = false;
                            proceedBtn.innerHTML = '<i class="fa fa-check me-2"></i>Proceed with Payment';
                        }
                    };
                      } else {
                    this._showFloossError(message || "OTP verification failed");
                }

            } catch (err) {
                if (err.message.includes('OTP has expired')) {
                    // Show Try Again button, hide Verify
                    tryAgainBtn.classList.remove('d-none');
                    submitBtn.classList.add('d-none');
                    this._showFloossError("OTP has expired, please resend the OTP");
                } else {
                    this._showFloossError(err.message);
                }
            }
        };

        // Handle Try Again click
        tryAgainBtn.onclick = async () => {
            tryAgainBtn.classList.add('d-none');
            submitBtn.classList.remove('d-none');
            errorBox.classList.add('d-none');
            document.getElementById('floossOtpInput').value = '';

            // Re-run OTP request
            await this._floossOnClick();
        };

        // Cancel handler
        cancelBtn.onclick = () => {
            modal.hide();
        };
    },

    _resetModalState() {
        // Reset all modal elements to default state
        const elements = [
            'floossOtpInfo',
            'floossOtpError',
            'floossOtpSuccess',
            'floossProceedPayment',
            'floossCancelPayment',
            'floossOtpSubmit',
            'floossOtpTryAgain'
        ];

        elements.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.add('d-none');
        });

        // Reset OTP input div
        const otpInputDiv = document.querySelector('#floossOtpInput')?.closest('.mb-3');
        if (otpInputDiv) otpInputDiv.classList.add('d-none');
    },

    _showFloossError(msg) {
        const errBox = document.getElementById('floossOtpError');
        if (errBox) {
            errBox.textContent = msg;
            errBox.classList.remove('d-none');
        }

        document.getElementById('floossOtpSuccess')?.classList.add('d-none');
        document.getElementById('floossOtpInfo')?.classList.add('d-none');

        console.error('Flooss Error:', msg);
    },

    _showFloossSuccess(msg) {
        const successBox = document.getElementById('floossOtpSuccess');
        if (successBox) {
            successBox.textContent = msg;
            successBox.classList.remove('d-none');
        }

        document.getElementById('floossOtpError')?.classList.add('d-none');
        document.getElementById('floossOtpInfo')?.classList.add('d-none');

        console.log('Flooss Success:', msg);
    }
});